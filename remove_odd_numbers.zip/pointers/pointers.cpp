// pointers.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;

int number[6] ={1,8,9,6,4,5 };
int nums[6] = {};

int arr[4];


int temp_size = 1;



int countEven();
int countOdd();

int *orderedarray(int nums[]);
int *getEvenNumbersInOrder();
bool checkArray(int size,int numsarray[] , int mainarray[]);

int  addnumber();

int main()
{
   
    checkArray(3, nums, number);

    cout << "add all integer  array output ====......" << endl;
    cout<< "The total sum of an integer array using pointer is "  <<addnumber() <<endl;
 
    std::cout << "the  count of even numbers is = " << countEven()<<endl;
    std::cout << "the  count of odd numbers is = " << countOdd() <<endl;

    std::cout << "numbers in an un ordered array are"<<endl;
    for (int i = 0; i < 6; i++) {
        std::cout<<" -----> "<< number[i] <<endl;
    }

    std::cout<<"remove all odd numbers from an ordered array by set the value of that cell to 0 The array should remain ordered " << endl;
    for (int i = 0; i < 6; i++) {
        std::cout << " ----> " <<getEvenNumbersInOrder()[i] << endl;
    }  
}
//add with a pointer an return   the  total
int addnumber(){
    int sum = *number;

    for(int i = 1; i < 6; i++) {
        sum += *(number  + i);
    }
    return sum;
}
// count the number of even numbers
int countEven(){
    int  count =  0;
    for (int i = 0; i < 6; i++) {
        int temp = number[i] % 2;
        if (temp == 0) {
            count++;
        }
    }
    return  count;
}
int countOdd() {
    int count = 0;
    for (int i = 0; i < 6; i++) {
        int temp = number[i] % 2;
        if (temp != 0) {
            count++;
        }
    }
    return count;
}
//remove all odd numbers in  array
int* getEvenNumbersInOrder() {

    for (int i = 0; i < 6; i++) {
        int temp = number[i] % 2;
        if (temp == 0) {
           nums[i] = number[i];
           nums[6 - 1] = 0;
        }
    }

    return orderedarray(nums);
  
}
bool checkArray(int size, int oddarray[], int mainarray[] ) {
    bool isfalse = true;
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            if (oddarray[i] == mainarray[j]) {
                isfalse = false;
            }
        }
        
    }
    return  isfalse;
}
// oder the array
int *orderedarray(int nums[]) {
    for (int i = 0; i < 6; i++) {
        int emp = i;
        for (int j = i + 1; j < 6; j++) {
            if(nums[j] < nums[i]) {
                emp = j;
            }
            
            
        }
         int temp = nums[i];
         nums[i] = nums[emp];
         nums[emp] = temp;

    }
    return nums;
}




// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
